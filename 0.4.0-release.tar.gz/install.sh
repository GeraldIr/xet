#!/usr/bin/env bash

cp bump/bump /usr/local/bin/bump
chmod +x /usr/local/bin/bump 