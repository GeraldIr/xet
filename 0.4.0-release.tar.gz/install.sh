#!/usr/bin/env bash

cp xet/xet /usr/local/bin/xet
chmod +x /usr/local/bin/xet 