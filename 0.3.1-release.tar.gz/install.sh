#!/usr/bin/env bash

cp bumpy/bump /usr/local/bin/bump
chmod +x /usr/local/bin/bump 