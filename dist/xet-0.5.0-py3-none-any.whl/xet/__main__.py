if __name__ == "__main__":
    from xet.cli import main

    main()
